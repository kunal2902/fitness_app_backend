import dotenv from 'dotenv';

dotenv.config();

/**
 * Reads a required variable, failing loudly at boot rather than at the
 * first request that needs it.
 */
function required(name: string, fallback?: string): string {
  const value = process.env[name] ?? fallback;
  if (value === undefined || value === '') {
    throw new Error(
      `Missing required environment variable: ${name}. ` +
        'Copy .env.example to .env and fill it in.',
    );
  }
  return value;
}

function optionalNumber(name: string, fallback: number): number {
  const raw = process.env[name];
  if (!raw) return fallback;
  const parsed = Number(raw);
  return Number.isFinite(parsed) ? parsed : fallback;
}

const nodeEnv = process.env.NODE_ENV ?? 'development';

export const env = {
  nodeEnv,
  isProduction: nodeEnv === 'production',
  isDevelopment: nodeEnv === 'development',

  port: optionalNumber('PORT', 3000),
  apiPrefix: process.env.API_PREFIX ?? '/api/v1',

  // The project's .env already uses MONGO_URI; MONGODB_URI is accepted as
  // an alias so either spelling works.
  mongoUri: required(
    'MONGO_URI',
    process.env.MONGODB_URI ?? 'mongodb://127.0.0.1:27017/fitness_app',
  ),

  jwt: {
    accessSecret: required(
      'JWT_ACCESS_SECRET',
      nodeEnv === 'production' ? undefined : 'dev-access-secret-change-me',
    ),
    refreshSecret: required(
      'JWT_REFRESH_SECRET',
      nodeEnv === 'production' ? undefined : 'dev-refresh-secret-change-me',
    ),
    accessExpiresIn: process.env.JWT_ACCESS_EXPIRES_IN ?? '15m',
    refreshExpiresIn: process.env.JWT_REFRESH_EXPIRES_IN ?? '30d',
    issuer: process.env.JWT_ISSUER ?? 'fitness-app',
  },

  bcryptRounds: optionalNumber('BCRYPT_ROUNDS', 12),

  uploads: {
    /// Where avatar files land. Relative paths resolve from the process cwd.
    dir: process.env.UPLOAD_DIR ?? 'uploads',
    /// Public path prefix the files are served under (outside the API prefix,
    /// so the client can fetch them without an auth header).
    publicPath: '/uploads',
    maxAvatarBytes: optionalNumber('MAX_AVATAR_BYTES', 5 * 1024 * 1024),
  },

  /** Comma-separated list, or `*` in development. */
  corsOrigins: (process.env.CORS_ORIGINS ?? '*')
    .split(',')
    .map((o) => o.trim())
    .filter(Boolean),

  realtime: {
    /** How long an unanswered call rings before it is marked missed. */
    ringTimeoutSeconds: optionalNumber('CALL_RING_TIMEOUT_SECONDS', 45),
    /** Grace period for a reconnect before a call is torn down. */
    reconnectGraceSeconds: optionalNumber('CALL_RECONNECT_GRACE_SECONDS', 20),
  },

  ice: {
    /** Public STUN servers, comma separated. Free and stateless. */
    stunUrls: (
      process.env.STUN_URLS ??
      'stun:stun.l.google.com:19302,stun:stun1.l.google.com:19302'
    )
      .split(',')
      .map((u) => u.trim())
      .filter(Boolean),

    /**
     * coturn, e.g. `turn:turn.example.com:3478`. Without it, calls fail on
     * symmetric NAT — roughly one connection in six.
     */
    turnUrls: (process.env.TURN_URLS ?? '')
      .split(',')
      .map((u) => u.trim())
      .filter(Boolean),

    /**
     * coturn's `static-auth-secret`. Credentials are derived from it per
     * request and expire; the secret itself never reaches a device.
     */
    turnSecret: process.env.TURN_STATIC_AUTH_SECRET ?? '',
    turnCredentialTtlSeconds: optionalNumber('TURN_CREDENTIAL_TTL', 12 * 3600),
  },

  push: {
    /**
     * Path to a Firebase service-account JSON, or the JSON itself.
     * Unset simply disables Android push — the server still runs.
     */
    firebaseCredentials: process.env.FIREBASE_SERVICE_ACCOUNT ?? '',

    /** APNs VoIP — the only way to trigger CallKit on iOS. */
    apnsKeyP8: process.env.APNS_KEY_P8 ?? '',
    apnsKeyId: process.env.APNS_KEY_ID ?? '',
    apnsTeamId: process.env.APNS_TEAM_ID ?? '',
    /** Bundle id; the VoIP topic is this plus `.voip`. */
    apnsBundleId: process.env.APNS_BUNDLE_ID ?? 'com.fitnessapp.fitness_app',
    apnsProduction: process.env.APNS_PRODUCTION === 'true',
  },
} as const;
