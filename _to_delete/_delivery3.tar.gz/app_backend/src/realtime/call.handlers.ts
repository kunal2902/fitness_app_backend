import type { Server } from 'socket.io';

import { env } from '../config/env.js';
import { Conversation } from '../models/conversation.model.js';
import { callService } from '../services/call.service.js';
import { chatService } from '../services/chat.service.js';
import { pushService } from '../services/push.service.js';
import { buildIceServers, turnConfigured } from '../services/turn.service.js';
import {
  SocketEvents,
  callRoom,
  userRoom,
  type CallIcePayload,
  type CallIdPayload,
  type CallInvitePayload,
  type CallRejectPayload,
  type CallSdpPayload,
} from './events.js';
import { presence } from './presence.js';
import {
  safeAck,
  socketError,
  type AppSocket,
  type SocketSession,
} from './socket.js';

/**
 * Narrows a client-supplied reject reason to one the call log accepts.
 *
 * A whitelist, not a default-to-declined coercion: the callee's own ring
 * timeout rejects with 'missed', and folding that into 'declined' writes
 * "Video call declined" into the thread for a call nobody ever saw.
 * Exported so selfcheck can pin the mapping — it is the kind of thing a
 * later edit silently un-fixes.
 */
export function normaliseRejectReason(
  raw: unknown,
): 'declined' | 'busy' | 'missed' {
  return raw === 'busy' || raw === 'missed' ? raw : 'declined';
}

/**
 * WebRTC signalling.
 *
 * The server relays offers, answers and ICE candidates without ever
 * parsing them — it only checks that the sender is one of the two people
 * on the call. Media flows peer-to-peer (or through TURN); it never
 * touches this process.
 */
export function registerCallHandlers(io: Server, socket: AppSocket): void {
  const session = socket.data as unknown as SocketSession;

  /** Relays a signalling payload to the other participant's devices. */
  const relay = async (
    event: string,
    payload: { callId?: string },
    ack: unknown,
  ) => {
    const respond = safeAck(ack);
    try {
      const call = await callService.requireParticipant(
        payload?.callId ?? '',
        session.objectId,
      );

      const otherId = call.caller.equals(session.objectId)
        ? call.callee
        : call.caller;

      io.to(userRoom(otherId.toString())).emit(event, {
        ...payload,
        fromUserId: session.userId,
      });
      respond({ ok: true });
    } catch (error) {
      respond(socketError(error));
    }
  };

  // -------------------------------------------------------------------------
  // Invite
  // -------------------------------------------------------------------------

  socket.on(SocketEvents.callInvite, async (payload: CallInvitePayload, ack) => {
    const respond = safeAck<{
      iceServers: unknown;
      turnAvailable: boolean;
      calleeOnline: boolean;
    }>(ack);

    try {
      const conversation = await chatService.requireParticipant(
        payload?.conversationId ?? '',
        session.objectId,
      );

      const calleeId = conversation.participants.find(
        (id) => !id.equals(session.objectId),
      );
      if (!calleeId) throw new Error('NO_CALLEE');

      // Two people cannot ring the same person at once, and nobody can be
      // on two calls. Checked before creating so the second caller gets a
      // clean busy signal rather than a half-created session.
      const busy = await callService.activeCallFor(calleeId);
      if (busy) {
        respond({
          ok: false,
          message: 'They are on another call right now.',
          code: 'CALLEE_BUSY',
        });
        return;
      }

      const call = await callService.create({
        callId: payload.callId,
        conversation,
        callerId: session.objectId,
        withVideo: payload.withVideo !== false,
      });

      await socket.join(callRoom(call.callId));

      const calleeOnline = presence.isOnline(calleeId.toString());

      io.to(userRoom(calleeId.toString())).emit(SocketEvents.callIncoming, {
        callId: call.callId,
        conversationId: conversation._id.toString(),
        withVideo: call.withVideo,
        caller: {
          id: session.userId,
          name: session.fullName,
          avatarUrl: session.avatarUrl,
        },
        expiresInSeconds: env.realtime.ringTimeoutSeconds,
      });

      // Ring the device even when no socket is open. Push is best-effort:
      // a failure here must not abort a call that may still connect via
      // the socket the callee has open.
      void pushService
        .sendCallInvite(calleeId.toString(), {
          callId: call.callId,
          conversationId: conversation._id.toString(),
          callerId: session.userId,
          callerName: session.fullName,
          callerAvatarUrl: session.avatarUrl,
          withVideo: call.withVideo,
        })
        .catch((error: unknown) => {
          console.error('[call] push invite failed:', error);
        });

      respond({
        ok: true,
        iceServers: buildIceServers(session.userId),
        turnAvailable: turnConfigured(),
        calleeOnline,
      });
    } catch (error) {
      respond(socketError(error));
    }
  });

  // -------------------------------------------------------------------------
  // Accept / reject / cancel / end
  // -------------------------------------------------------------------------

  socket.on(SocketEvents.callAccept, async (payload: CallIdPayload, ack) => {
    const respond = safeAck<{ iceServers: unknown; turnAvailable: boolean }>(ack);
    try {
      const call = await callService.requireParticipant(
        payload?.callId ?? '',
        session.objectId,
      );

      if (!call.callee.equals(session.objectId)) {
        respond({
          ok: false,
          message: 'Only the person being called can accept.',
          code: 'NOT_CALLEE',
        });
        return;
      }
      if (call.state === 'ended') {
        respond({
          ok: false,
          message: 'That call has already ended.',
          code: 'CALL_ENDED',
        });
        return;
      }

      await callService.markAccepted(call);
      await socket.join(callRoom(call.callId));

      respond({
        ok: true,
        iceServers: buildIceServers(session.userId),
        turnAvailable: turnConfigured(),
      });

      io.to(userRoom(call.caller.toString())).emit(SocketEvents.callAccepted, {
        callId: call.callId,
        acceptedBy: session.userId,
      });

      // Stop the callee's *other* devices ringing.
      socket.to(userRoom(session.userId)).emit(SocketEvents.callCancelled, {
        callId: call.callId,
        reason: 'answered_elsewhere',
      });
      void pushService.sendCallCancelled(session.userId, call.callId);
    } catch (error) {
      respond(socketError(error));
    }
  });

  socket.on(SocketEvents.callReject, async (payload: CallRejectPayload, ack) => {
    const respond = safeAck(ack);
    try {
      const call = await callService.requireParticipant(
        payload?.callId ?? '',
        session.objectId,
      );

      const reason = normaliseRejectReason(payload?.reason);

      const { alreadyEnded } = await callService.end(call, reason);
      respond({ ok: true });
      if (alreadyEnded) return;

      io.to(userRoom(call.caller.toString())).emit(SocketEvents.callRejected, {
        callId: call.callId,
        reason,
      });
      socket.to(userRoom(session.userId)).emit(SocketEvents.callCancelled, {
        callId: call.callId,
        reason: 'handled_elsewhere',
      });

      await appendCallEntry(io, call.callId);
      void pushService.sendCallCancelled(session.userId, call.callId);
    } catch (error) {
      respond(socketError(error));
    }
  });

  socket.on(SocketEvents.callCancel, async (payload: CallIdPayload, ack) => {
    const respond = safeAck(ack);
    try {
      const call = await callService.requireParticipant(
        payload?.callId ?? '',
        session.objectId,
      );

      // Hanging up before the other side answers is a cancel; after, it is
      // a completed call. The distinction is what the chat row shows.
      const wasRinging = call.state === 'ringing';
      const { alreadyEnded } = await callService.end(
        call,
        wasRinging ? 'cancelled' : 'completed',
      );
      respond({ ok: true });
      if (alreadyEnded) return;

      io.to(userRoom(call.callee.toString())).emit(SocketEvents.callCancelled, {
        callId: call.callId,
        reason: 'cancelled',
      });
      await appendCallEntry(io, call.callId);
      void pushService.sendCallCancelled(call.callee.toString(), call.callId);
    } catch (error) {
      respond(socketError(error));
    }
  });

  socket.on(SocketEvents.callEnd, async (payload: CallIdPayload, ack) => {
    const respond = safeAck(ack);
    try {
      const call = await callService.requireParticipant(
        payload?.callId ?? '',
        session.objectId,
      );

      const wasRinging = call.state === 'ringing';
      const { alreadyEnded } = await callService.end(
        call,
        wasRinging ? 'cancelled' : 'completed',
      );
      respond({ ok: true });
      if (alreadyEnded) return;

      const otherId = call.caller.equals(session.objectId)
        ? call.callee
        : call.caller;

      io.to(userRoom(otherId.toString())).emit(SocketEvents.callEnded, {
        callId: call.callId,
        endedBy: session.userId,
        durationSeconds: call.durationSeconds ?? 0,
      });

      await appendCallEntry(io, call.callId);
    } catch (error) {
      respond(socketError(error));
    }
  });

  // -------------------------------------------------------------------------
  // Signalling relay — payloads are opaque
  // -------------------------------------------------------------------------

  socket.on(SocketEvents.callOffer, (payload: CallSdpPayload, ack) => {
    void relay(SocketEvents.callOffer, payload, ack);
  });

  socket.on(SocketEvents.callAnswer, async (payload: CallSdpPayload, ack) => {
    await relay(SocketEvents.callAnswer, payload, ack);
    // An answer means media is being negotiated — the call is live.
    try {
      const call = await callService.find(payload?.callId ?? '');
      if (call) await callService.markConnected(call);
    } catch {
      // Bookkeeping only; never fail the answer over it.
    }
  });

  socket.on(SocketEvents.callIce, (payload: CallIcePayload, ack) => {
    void relay(SocketEvents.callIce, payload, ack);
  });
}

/** Writes the finished call into the chat thread. */
async function appendCallEntry(io: Server, callId: string): Promise<void> {
  try {
    const call = await callService.find(callId);
    if (!call) return;

    const conversation = await Conversation.findById(call.conversation);
    if (!conversation) return;

    await callService.appendCallMessage(call, conversation);

    // Refresh both timelines so the call row appears without a reload.
    for (const participant of conversation.participants) {
      io.to(userRoom(participant.toString())).emit(SocketEvents.chatDelivered, {
        conversationId: conversation._id.toString(),
        message: null,
        refresh: true,
      });
    }
  } catch (error) {
    console.error('[call] could not append call entry:', error);
  }
}

/**
 * Ends calls nobody answered.
 *
 * Without this a caller who force-quits leaves the callee permanently
 * "busy", and no missed-call row is ever written.
 */
export function startRingTimeoutSweeper(io: Server): NodeJS.Timeout {
  const timer = setInterval(() => {
    void (async () => {
      try {
        const expired = await callService.expiredRingingCalls();
        for (const call of expired) {
          const { alreadyEnded } = await callService.end(call, 'missed');
          if (alreadyEnded) continue;

          io.to(userRoom(call.caller.toString())).emit(
            SocketEvents.callEnded,
            { callId: call.callId, reason: 'missed', durationSeconds: 0 },
          );
          io.to(userRoom(call.callee.toString())).emit(
            SocketEvents.callCancelled,
            { callId: call.callId, reason: 'missed' },
          );

          await appendCallEntry(io, call.callId);
          void pushService.sendCallCancelled(
            call.callee.toString(),
            call.callId,
          );
        }
      } catch (error) {
        console.error('[call] ring sweeper failed:', error);
      }
    })();
  }, 10_000);

  // Must not keep the process alive on shutdown.
  timer.unref();
  return timer;
}
