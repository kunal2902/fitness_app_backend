import mongoose from 'mongoose';

import { env } from '../config/env.js';
import {
  CallSession,
  type CallEndReason,
  type CallSessionDocument,
} from '../models/callSession.model.js';
import type { ConversationDocument } from '../models/conversation.model.js';
import { ApiError } from '../utils/apiError.js';
import { chatService } from './chat.service.js';

/**
 * Call lifecycle, independent of transport.
 *
 * The server never sees media — that is peer-to-peer. What it owns is the
 * *state machine*: who may signal to whom, when a call has rung too long,
 * and what gets written into the chat thread afterwards.
 */
export const callService = {
  /** A user already on a call cannot be rung by someone else. */
  async activeCallFor(
    userId: mongoose.Types.ObjectId,
  ): Promise<CallSessionDocument | null> {
    return CallSession.findOne({
      state: { $in: ['ringing', 'accepted', 'connected'] },
      $or: [{ caller: userId }, { callee: userId }],
    });
  },

  async create(params: {
    callId: string;
    conversation: ConversationDocument;
    callerId: mongoose.Types.ObjectId;
    withVideo: boolean;
  }): Promise<CallSessionDocument> {
    const callee = params.conversation.participants.find(
      (id) => !id.equals(params.callerId),
    );
    if (!callee) {
      throw ApiError.badRequest('No one to call', 'NO_CALLEE');
    }

    // The client supplies callId so it can wire its peer connection before
    // the round trip; a collision means a repeat or a spoof, so reject it.
    const existing = await CallSession.findOne({ callId: params.callId });
    if (existing) {
      throw ApiError.conflict('That call already exists', 'CALL_EXISTS');
    }

    return CallSession.create({
      callId: params.callId,
      conversation: params.conversation._id,
      caller: params.callerId,
      callee,
      withVideo: params.withVideo,
      state: 'ringing',
      ringingAt: new Date(),
    });
  },

  async find(callId: string): Promise<CallSessionDocument | null> {
    return CallSession.findOne({ callId });
  },

  /**
   * Loads a call and asserts the caller is one of its two participants.
   *
   * Every signalling event goes through this. Without it, knowing a callId
   * would be enough to inject SDP into someone else's call.
   */
  async requireParticipant(
    callId: string,
    userId: mongoose.Types.ObjectId,
  ): Promise<CallSessionDocument> {
    const call = await CallSession.findOne({ callId });
    if (!call) throw ApiError.notFound('Call not found', 'NO_CALL');

    if (!call.caller.equals(userId) && !call.callee.equals(userId)) {
      throw ApiError.notFound('Call not found', 'NO_CALL');
    }
    return call;
  },

  async markAccepted(call: CallSessionDocument): Promise<CallSessionDocument> {
    if (call.state !== 'ringing') return call;
    call.state = 'accepted';
    call.acceptedAt = new Date();
    await call.save();
    return call;
  },

  async markConnected(call: CallSessionDocument): Promise<CallSessionDocument> {
    if (call.state === 'ended') return call;
    call.state = 'connected';
    call.connectedAt ??= new Date();
    await call.save();
    return call;
  },

  /**
   * Terminal transition. Idempotent — both peers usually report the end,
   * and a hangup racing a timeout must not produce two chat entries.
   */
  async end(
    call: CallSessionDocument,
    reason: CallEndReason,
  ): Promise<{ call: CallSessionDocument; alreadyEnded: boolean }> {
    if (call.state === 'ended') {
      return { call, alreadyEnded: true };
    }

    const endedAt = new Date();
    const startedAt = call.connectedAt ?? call.acceptedAt;

    call.state = 'ended';
    call.endReason = reason;
    call.endedAt = endedAt;
    call.durationSeconds = startedAt
      ? Math.max(0, Math.round((endedAt.getTime() - startedAt.getTime()) / 1000))
      : 0;

    await call.save();
    return { call, alreadyEnded: false };
  },

  /**
   * Writes the call into the chat thread so history reads as one timeline
   * rather than messages here and calls somewhere else.
   */
  async appendCallMessage(
    call: CallSessionDocument,
    conversation: ConversationDocument,
  ): Promise<void> {
    const outcome = outcomeFor(call.endReason ?? 'failed');

    await chatService.sendMessage({
      conversation,
      // Attributed to the caller: "you called" / "they called".
      senderId: call.caller,
      kind: 'call',
      body: describe(call.withVideo, outcome, call.durationSeconds ?? 0),
      callId: call.callId,
      callOutcome: outcome,
      callDurationSeconds: call.durationSeconds ?? 0,
      callWithVideo: call.withVideo,
    });
  },

  /** Calls still ringing past the timeout, for the sweeper to clean up. */
  async expiredRingingCalls(): Promise<CallSessionDocument[]> {
    const cutoff = new Date(
      Date.now() - env.realtime.ringTimeoutSeconds * 1000,
    );
    return CallSession.find({ state: 'ringing', ringingAt: { $lt: cutoff } });
  },
};

function outcomeFor(reason: CallEndReason) {
  switch (reason) {
    case 'completed':
      return 'completed' as const;
    case 'declined':
      return 'declined' as const;
    case 'cancelled':
      return 'cancelled' as const;
    case 'missed':
      return 'missed' as const;
    case 'busy':
      return 'declined' as const;
    default:
      return 'failed' as const;
  }
}

function describe(
  withVideo: boolean,
  outcome: ReturnType<typeof outcomeFor>,
  seconds: number,
): string {
  const kind = withVideo ? 'Video call' : 'Voice call';
  switch (outcome) {
    case 'completed':
      return `${kind} · ${formatDuration(seconds)}`;
    case 'missed':
      return `Missed ${kind.toLowerCase()}`;
    case 'declined':
      return `${kind} declined`;
    case 'cancelled':
      return `${kind} cancelled`;
    default:
      return `${kind} failed`;
  }
}

function formatDuration(seconds: number): string {
  if (seconds < 60) return `${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  const rest = seconds % 60;
  if (minutes < 60) return `${minutes}m ${rest}s`;
  const hours = Math.floor(minutes / 60);
  return `${hours}h ${minutes % 60}m`;
}
