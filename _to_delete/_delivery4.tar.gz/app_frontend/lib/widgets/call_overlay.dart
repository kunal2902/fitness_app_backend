import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../blocs/call/call_bloc.dart';
import '../models/call_models.dart';
import '../screens/call/call_screen.dart';
import '../screens/call/incoming_call_screen.dart';
import '../services/call_window_service.dart';

/// Puts the call UI above everything else.
///
/// An overlay rather than a route: a call can start from any screen, at
/// any moment, including from a push while the user is deep in a
/// navigation stack. Pushing a route would mean guessing which navigator
/// to push onto and unwinding it correctly afterwards — this simply draws
/// on top and disappears when the call ends, leaving the stack untouched.
class CallOverlay extends StatelessWidget {
  const CallOverlay({required this.child, super.key});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<CallBloc, CallState>(
      listenWhen: (CallState a, CallState b) => a.phase != b.phase,
      listener: (BuildContext context, CallState state) {
        // Show over the lock screen and keep the screen awake for as long
        // as there is a call — and, just as importantly, stop doing both
        // the moment there is not. This is the only place that knows the
        // call UI is up, so it is the only place that can turn it off.
        unawaited(
          CallWindowService.instance.setCallActive(
            state.isActive || state.phase == CallPhase.ended,
          ),
        );

        if (state.phase != CallPhase.ended) return;

        // Hold the outcome on screen briefly — "Call declined" that
        // vanishes in a frame just reads as the call failing silently.
        Timer(const Duration(milliseconds: 1600), () {
          if (!context.mounted) return;
          final CallBloc bloc = context.read<CallBloc>();
          if (bloc.state.phase == CallPhase.ended) {
            bloc.add(const CallDismissed());
          }
        });
      },
      buildWhen: (CallState a, CallState b) =>
          a.phase != b.phase || a.isOutgoing != b.isOutgoing,
      builder: (BuildContext context, CallState state) {
        final bool showCallUi =
            state.isActive || state.phase == CallPhase.ended;

        return Stack(
          children: <Widget>[
            child,
            if (showCallUi)
              Positioned.fill(
                child: _CallSurface(
                  // Keyed by phase-group so answering an incoming call
                  // rebuilds into the in-call screen rather than trying to
                  // morph one into the other.
                  key: ValueKey<bool>(state.isRinging && !state.isOutgoing),
                  isIncoming: state.isRinging && !state.isOutgoing,
                ),
              ),
          ],
        );
      },
    );
  }
}

class _CallSurface extends StatelessWidget {
  const _CallSurface({required this.isIncoming, super.key});

  final bool isIncoming;

  @override
  Widget build(BuildContext context) {
    // BackButtonListener, not PopScope. PopScope only governs the route
    // it sits inside, and this widget is drawn from MaterialApp.builder —
    // above the Navigator, inside no route at all — so a PopScope here
    // is inert and Android back would pop whatever screen is hiding
    // behind the call, leaving the media running on a dead surface.
    // BackButtonListener registers with WidgetsBinding directly and the
    // innermost registered listener wins, which is exactly this one while
    // the call UI is up.
    return BackButtonListener(
      onBackButtonPressed: () async => true, // swallow it
      child: Material(
        color: Colors.transparent,
        child: isIncoming ? const IncomingCallScreen() : const CallScreen(),
      ),
    );
  }
}
